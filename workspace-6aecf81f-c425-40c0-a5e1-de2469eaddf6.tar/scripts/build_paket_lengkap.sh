#!/bin/bash
# ============================================================
# Membangun cek-blok-paket-lengkap.zip
# SATU paket unduhan berisi SEMUA file proyek Cek Blok:
#   1. Server (backend + web app)  = cek-blok-server-github.zip
#   2. APK Android                 = Cek-Blok.apk
#   3. Salinan web app terpisah    = isi public/app/
# Plus: BACA-DULU-PENTING.txt (petunjuk pemakaian tiap bagian)
# ============================================================
set -euo pipefail

ROOT="/home/z/my-project"
OUT_DIR="$ROOT/download"
STAGE="$ROOT/.zipstage-full"
PKG="$OUT_DIR/cek-blok-paket-lengkap.zip"
SERVER_ZIP="$OUT_DIR/cek-blok-server-github.zip"
APK="$ROOT/upload/Cek-Blok.apk"

cd "$ROOT"
mkdir -p "$OUT_DIR"

# Pastikan ZIP server terbaru sudah ada (build bila belum)
if [ ! -f "$SERVER_ZIP" ]; then
  bash "$ROOT/scripts/build_project_zip.sh"
fi

# Staging bersih
rm -rf "$STAGE"
mkdir -p "$STAGE/1-SERVER-unggah-ke-GITHUB" \
         "$STAGE/2-APK-Android" \
         "$STAGE/3-WEB-APP-salinan-terpisah"

# --- Isi paket ---
BACA="$OUT_DIR/BACA-DULU-PENTING.txt"
[ -s "$BACA" ] || { echo "HILANG: BACA-DULU-PENTING.txt — buat dulu di download/" >&2; exit 1; }

cp "$BACA"       "$STAGE/BACA-DULU-PENTING.txt"
cp "$SERVER_ZIP" "$STAGE/1-SERVER-unggah-ke-GITHUB/"
cp "$APK"        "$STAGE/2-APK-Android/Cek-Blok.apk"
cp -r "$ROOT/public/app/." "$STAGE/3-WEB-APP-salinan-terpisah/"

# --- Validasi isi sebelum zip ---
[ -s "$STAGE/BACA-DULU-PENTING.txt" ] || { echo "HILANG: BACA-DULU" >&2; exit 1; }
[ -s "$STAGE/1-SERVER-unggah-ke-GITHUB/cek-blok-server-github.zip" ] || { echo "HILANG: server zip" >&2; exit 1; }
[ -s "$STAGE/2-APK-Android/Cek-Blok.apk" ] || { echo "HILANG: APK" >&2; exit 1; }
[ -s "$STAGE/3-WEB-APP-salinan-terpisah/index.html" ] || { echo "HILANG: web app" >&2; exit 1; }

# --- Buat zip gabungan ---
rm -f "$PKG"
cd "$STAGE"
zip -r -q "$PKG" .
cd "$ROOT"
rm -rf "$STAGE"

echo "=== PAKET LENGKAP SELESAI ==="
ls -lh "$PKG" "$SERVER_ZIP" "$APK"
