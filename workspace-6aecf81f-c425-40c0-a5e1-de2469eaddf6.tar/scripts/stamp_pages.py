#!/usr/bin/env python3
"""Stempel nomor halaman: cover (hal-1 PDF) tanpa nomor; isi mulai dari 1."""
import io, sys
from pypdf import PdfReader, PdfWriter
from reportlab.pdfgen import canvas

SRC = '/home/z/my-project/download/panduan-cekblok-github.pdf'
DST = SRC  # timpa di tempat

reader = PdfReader(SRC)
writer = PdfWriter()
n = len(reader.pages)
box = reader.pages[0].mediabox
W, H = float(box.width), float(box.height)
print(f"halaman: {n}, ukuran: {W:.0f}x{H:.0f} pt")

for i, page in enumerate(reader.pages):
    if i == 0:
        writer.add_page(page)  # cover: tanpa nomor
        continue
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(W, H))
    c.setFont('Helvetica', 8.5)
    c.setFillColorRGB(0.486, 0.475, 0.447)  # #7c7972 muted
    c.drawCentredString(W / 2, 14, str(i))  # isi mulai dari 1
    c.save()
    buf.seek(0)
    overlay = PdfReader(buf).pages[0]
    page.merge_page(overlay)
    writer.add_page(page)

with open(DST, 'wb') as f:
    writer.write(f)
print(f"nomor halaman distempel: halaman 2..{n} => 1..{n-1}")
