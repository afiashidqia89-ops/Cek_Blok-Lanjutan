#!/usr/bin/env python3
"""
Patch index.html aplikasi Cek Blok (APK Capacitor):
- Menambah panel "Sinkronisasi Server" di halaman Riwayat
- Menambah tombol Kirim ke Server / Ambil dari Server (tanpa file manager)
- Menambah pengaturan alamat server + token perangkat (localStorage)

Hasil: /home/z/my-project/public/app/index.html (+ aset pendukung)
Asli tidak diubah: /home/z/my-project/apk-analysis/extracted/assets/public/index.html
"""
import os
import shutil
import sys

SRC = "/home/z/my-project/apk-analysis/extracted/assets/public"
OUT = "/home/z/my-project/public/app"

PANEL_HTML = '''<div class="history-data-tools report-box" id="serverSyncBox" aria-label="Sinkronisasi server" style="border-color:#a7f3d0;background:linear-gradient(135deg,#ecfdf5,#fff);flex-direction:column;align-items:stretch">
        <div class="history-data-tools-copy"><b style="color:#166534">Sinkronisasi Server (Internet)</b><small>Kirim / ambil data langsung ke server Cek Blok. Yang menerima TIDAK perlu file manager — data digabung otomatis, duplikat dilewati.</small></div>
        <div class="report-actions">
          <button type="button" class="primary" id="srvSendBtn">☁️ Kirim ke Server</button>
          <button type="button" class="secondary" id="srvFetchBtn">⬇️ Ambil dari Server</button>
          <button type="button" class="secondary" id="srvCfgBtn">⚙️ Server &amp; Token</button>
        </div>
        <div id="srvCfgPanel" hidden style="display:flex;flex-direction:column;gap:8px;padding:10px;border:1px dashed #a7f3d0;border-radius:10px;margin-top:8px">
          <label style="font-size:12px;color:#374151">Alamat server
            <input id="srvUrlInput" type="url" placeholder="https://alamat-server-anda" style="width:100%;margin-top:4px;padding:8px;border:1px solid #d1d5db;border-radius:8px;font-size:13px">
          </label>
          <label style="font-size:12px;color:#374151">Token perangkat
            <input id="srvTokenInput" type="text" placeholder="cbk_..." style="width:100%;margin-top:4px;padding:8px;border:1px solid #d1d5db;border-radius:8px;font-size:13px;font-family:monospace">
          </label>
          <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
            <button type="button" class="secondary" id="srvSaveBtn">Simpan</button>
            <button type="button" class="secondary" id="srvTestBtn">Tes Koneksi</button>
            <small id="srvTestInfo" style="color:#6b7280"></small>
          </div>
          <small style="color:#6b7280;font-size:11px">Token dibuat di web admin: menu Token Perangkat → Buat Token.</small>
        </div>
        <small id="srvStatus" style="color:#6b7280;padding-left:2px"></small>
      </div>'''

PATCH_JS = r'''<script>
/* ====== Sinkronisasi Server Cek Blok (patch integrasi web server) ====== */
(function(){
  var SRV_URL_KEY='cekBlokServerUrl', SRV_TOK_KEY='cekBlokServerToken', SRV_SYNC_KEY='cekBlokServerLastSync';
  function $(id){ return document.getElementById(id); }
  function cfg(){ var u='',t=''; try{ u=localStorage.getItem(SRV_URL_KEY)||''; t=localStorage.getItem(SRV_TOK_KEY)||''; }catch(e){} return {u:u,t:t}; }
  function norm(u){ return String(u||'').trim().replace(/\/+$/,''); }
  function setSt(s){ var el=$('srvStatus'); if(el) el.textContent=s; }
  function tokHeaders(){ var c=cfg(); return { 'Authorization':'Bearer '+c.t, 'Content-Type':'application/json' }; }
  function openCfg(){ var p=$('srvCfgPanel'); if(!p) return; var c=cfg(); $('srvUrlInput').value=c.u; $('srvTokenInput').value=c.t; p.hidden=false; }
  function perangkat(){ var nm=''; try{ nm=localStorage.getItem('cekBlokNamaPerangkat')||''; }catch(e){} if(!nm){ var p=document.getElementById('pemeriksa'); nm=(p&&p.value||'').trim(); } return nm||'HP'; }
  function srvLastSync(){ try{ return Number(localStorage.getItem(SRV_SYNC_KEY)||0)||0; }catch(e){ return 0; } }
  function stripPhoto(r){ return JSON.parse(JSON.stringify(r, function(k,v){ return k==='photo'?'':v; })); }

  async function srvSend(){
    var c=cfg();
    if(!c.u||!c.t){ openCfg(); alert('Isi dulu alamat server dan token perangkat.\nToken dibuat di web admin: menu Token Perangkat.'); return; }
    if(!records().length){ alert('Belum ada data transaksi untuk dikirim.'); return; }
    var btn=$('srvSendBtn'); btn.disabled=true; var old=btn.textContent; btn.textContent='Mengirim…';
    setSt('Mengirim ke server…');
    try{
      var rows=records().slice();
      var CH=3*1024*1024, groups=[], cur=[], sz=0;
      rows.forEach(function(r){ var s=JSON.stringify(r); if(cur.length&&sz+s.length>CH){ groups.push(cur); cur=[]; sz=0; } cur.push(r); sz+=s.length; });
      if(cur.length) groups.push(cur);
      var terima=0, baru=0, dup=0, tanpaFoto=false;
      for(var i=0;i<groups.length;i++){
        setSt('Mengirim bagian '+(i+1)+' dari '+groups.length+'…');
        var payload={ app:'cekblok-transfer', v:1, perangkat:perangkat(), dibuat:Date.now(), foto:!tanpaFoto, bagian:i+1, dari:groups.length, jumlah:groups[i].length, records: tanpaFoto?groups[i].map(stripPhoto):groups[i] };
        var res=await fetch(norm(c.u)+'/api/sync/upload', { method:'POST', headers:tokHeaders(), body:JSON.stringify(payload) });
        var j=await res.json().catch(function(){ return {}; });
        if((!res.ok||!j.ok)&&res.status===413&&!tanpaFoto){
          tanpaFoto=true; i=-1; terima=0; baru=0; dup=0;   /* ulang semua tanpa foto */
          continue;
        }
        if(!res.ok||!j.ok) throw new Error(j.error||('HTTP '+res.status));
        terima+=j.diterima||0; baru+=j.baru||0; dup+=j.duplikat||0;
      }
      try{ localStorage.setItem(SRV_SYNC_KEY, String(Date.now())); }catch(e){}
      setSt('Terakhir dikirim: '+new Date().toLocaleString('id-ID')+(tanpaFoto?' (tanpa foto)':''));
      alert('Kirim ke server selesai.\n\nTransaksi diperiksa: '+terima+'\nBaru tersimpan: '+baru+'\nDuplikat dilewati: '+dup+(tanpaFoto?'\n\nCatatan: data dikirim tanpa foto karena ukuran melebihi batas.':''));
    }catch(err){
      setSt('Gagal mengirim: '+err.message);
      alert('Gagal mengirim ke server: '+err.message+'\n\nPeriksa alamat server, token perangkat, dan koneksi internet.');
    }finally{ btn.disabled=false; btn.textContent=old; }
  }

  async function srvFetch(){
    var c=cfg();
    if(!c.u||!c.t){ openCfg(); alert('Isi dulu alamat server dan token perangkat.'); return; }
    var btn=$('srvFetchBtn'); btn.disabled=true; var old=btn.textContent; btn.textContent='Mengambil…';
    setSt('Mengambil data dari server…');
    try{
      var cur=records();
      var keys=new Set(cur.map(function(r,i){ return trfKey(r,i); }));
      var codes=new Set(cur.map(function(r,i){ return ensureTransactionCode(r,i); }));
      var toAdd=[], dup=0, cursor=0, totalSrv=0, jagaJeda=0;
      while(true){
        setSt('Mengambil data… ('+cursor+(totalSrv?' dari '+totalSrv:'')+')');
        var res=await fetch(norm(c.u)+'/api/sync/download?cursor='+cursor+'&dari='+srvLastSync(), { headers:tokHeaders() });
        var j=await res.json().catch(function(){ return {}; });
        if(!res.ok||!j.ok) throw new Error(j.error||('HTTP '+res.status));
        totalSrv=j.total||0;
        var inc=(j.records||[]).filter(function(r){ return r&&typeof r==='object'&&(r.blok||r.tanggal); });
        for(var k=0;k<inc.length;k++){
          var rk=trfKey(inc[k],0);
          if(keys.has(rk)){ dup++; continue; }
          keys.add(rk);
          var copy=Object.assign({}, inc[k]);
          if(!copy.kodeTransaksi) copy.kodeTransaksi=ensureTransactionCode(copy,0);
          if(codes.has(copy.kodeTransaksi)){ var n=2; while(codes.has(copy.kodeTransaksi+'-'+n)) n++; copy.kodeTransaksi+='-'+n; }
          codes.add(copy.kodeTransaksi);
          if(!copy.sumberPerangkat) copy.sumberPerangkat='SERVER';
          toAdd.push(copy);
        }
        if(j.selesai) break;
        if(j.nextCursor==null||(j.records&&!j.records.length&&j.nextCursor===cursor)) break;
        cursor=j.nextCursor;
        if(++jagaJeda>200) break;
      }
      if(!toAdd.length){ setSt('Server terkini: tidak ada data baru.'); alert('Tidak ada data baru dari server.\nDuplikat dilewati: '+dup); return; }
      if(!confirm('Gabungkan '+toAdd.length+' transaksi baru dari server?\nDuplikat dilewati: '+dup)) return;
      var merged=cur.concat(toAdd).map(function(r,i){ return {r:r,i:i}; })
        .sort(function(a,b){ return String(a.r.tanggal||'').localeCompare(String(b.r.tanggal||'')) || ((a.r.savedAt||0)-(b.r.savedAt||0)) || (a.i-b.i); })
        .map(function(x){ return x.r; });
      var ok=await saveRecords(merged);
      if(!ok) return;
      try{ localStorage.setItem(SRV_SYNC_KEY, String(Date.now())); }catch(e){}
      renderHistory();
      setSt('Terakhir ambil: '+new Date().toLocaleString('id-ID'));
      alert('Berhasil: '+toAdd.length+' transaksi baru digabung dari server.\nTotal transaksi sekarang: '+merged.length+'.');
    }catch(err){
      setSt('Gagal mengambil: '+err.message);
      alert('Gagal mengambil dari server: '+err.message);
    }finally{ btn.disabled=false; btn.textContent=old; }
  }

  async function srvTest(){
    var c=cfg(); var info=$('srvTestInfo');
    if(!c.u||!c.t){ if(info) info.textContent='Alamat server & token wajib diisi.'; return; }
    if(info) info.textContent='Menguji…';
    try{
      var res=await fetch(norm(c.u)+'/api/sync/status', { headers:tokHeaders() });
      var j=await res.json().catch(function(){ return {}; });
      if(!res.ok||!j.ok) throw new Error(j.error||('HTTP '+res.status));
      if(info) info.textContent='Terhubung ✓ ('+j.totalRecords+' transaksi di server)';
    }catch(err){ if(info) info.textContent='Gagal: '+err.message; }
  }

  function saveCfg(){
    try{
      localStorage.setItem(SRV_URL_KEY, ($('srvUrlInput').value||'').trim());
      localStorage.setItem(SRV_TOK_KEY, ($('srvTokenInput').value||'').trim());
      var p=$('srvCfgPanel'); if(p) p.hidden=true;
      setSt('Konfigurasi tersimpan. Server: '+($('srvUrlInput').value||'').trim());
    }catch(e){ alert('Tidak bisa menyimpan konfigurasi: '+e.message); }
  }

  function init(){
    if(!$('srvSendBtn')||!$('serverSyncBox')) return setTimeout(init, 300);
    $('srvSendBtn').addEventListener('click', srvSend);
    $('srvFetchBtn').addEventListener('click', srvFetch);
    $('srvCfgBtn').addEventListener('click', openCfg);
    var sv=$('srvSaveBtn'); if(sv) sv.addEventListener('click', saveCfg);
    var ts=$('srvTestBtn'); if(ts) ts.addEventListener('click', srvTest);
    var c=cfg(); if(c.u) setSt('Server: '+c.u);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
</script>'''


def main():
    if not os.path.isdir(SRC):
        print(f"Sumber tidak ada: {SRC}")
        sys.exit(1)
    os.makedirs(OUT, exist_ok=True)

    with open(os.path.join(SRC, "index.html"), "r", encoding="utf-8") as f:
        html = f.read()

    # --- Patch 1: panel UI sebelum kartu DB Aresta ---
    anchor_html = '<div class="history-data-tools db-tools report-box"'
    assert html.count(anchor_html) == 1, f"anchor HTML tidak unik: {html.count(anchor_html)}"
    html = html.replace(anchor_html, PANEL_HTML + "\n      " + anchor_html)

    # --- Patch 2: script sebelum </body> terakhir ---
    idx = html.rfind("</body>")
    assert idx > 0, "anchor </body> tidak ditemukan"
    html = html[:idx] + PATCH_JS + "\n" + html[idx:]

    with open(os.path.join(OUT, "index.html"), "w", encoding="utf-8") as f:
        f.write(html)

    # --- Salin aset pendukung aplikasi ---
    for name in ["exceljs.min.js", "pdf.min.js", "pdf.worker.min.js", "icon-192.png", "icon-512.png", "manifest.json"]:
        src_path = os.path.join(SRC, name)
        if os.path.isfile(src_path):
            shutil.copy2(src_path, os.path.join(OUT, name))
            print(f"  disalin: {name}")

    size = os.path.getsize(os.path.join(OUT, "index.html"))
    print(f"OK: public/app/index.html dibuat ({size/1024:.0f} KB) — panel server + tombol Kirim/Ambil aktif.")


if __name__ == "__main__":
    main()
